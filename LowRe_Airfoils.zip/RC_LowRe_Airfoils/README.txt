WingBuilder RC / Low-Re Airfoil Pack
===================================

This ZIP is a curated subset of airfoil .dat files selected for RC-scale use (typically low to moderate Reynolds numbers).
It is intended as a "good defaults" library for WingBuilder users who don't want to sift through thousands of airfoils.

What's inside
-------------
- A selection of well-known RC/low-Re families (when present in your airfoil database), including:
  - Drela AG series (gliders / efficient low-Re)
  - Selig SD series (classic low-Re performers)
  - Eppler E series (common RC airfoils)
  - MH series (often used for faster wings / sport gliders)
  - RG series (sport glider styles)
  - Clark Y variants (forgiving/general purpose)
  - Common NACA (2412/4412/230xx + symmetric 00xx for tails)
  - A small handful of other families if found (FX, NACA 6-series)

Notes / Tips
------------
- Start simple: same airfoil root->tip + mild washout (e.g., 0° root to -2° to -4° tip).
- If stall is sharp or tips drop first: add more washout, reduce taper, or use a milder tip airfoil.
- For fast wings: thinner/lower camber sections and less twist generally behave better.

This pack was built from your existing airfoil library by filename matching. If you don't see a favorite airfoil,
it may simply not be present in the source database or may use a different filename spelling.
